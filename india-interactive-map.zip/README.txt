
India Interactive Map (MapChart-style)

1. This app is COMPLETE and functional.
2. Upload this folder to GitHub Pages / Netlify / Cloudflare Pages to get a public link.
3. Add district GeoJSON files inside /geojson folder named like:
   KA.geojson, MH.geojson, UP.geojson etc.

Each GeoJSON feature must have:
  properties.district

Once uploaded, users can:
- Select a state
- Click districts to color them
- Use it like MapChart

